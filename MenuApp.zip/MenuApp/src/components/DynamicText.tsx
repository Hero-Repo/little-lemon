import {createText} from '@shopify/restyle';
import {Theme} from 'restyleTheme';

const DynamicText = createText<Theme>();

export default DynamicText;
