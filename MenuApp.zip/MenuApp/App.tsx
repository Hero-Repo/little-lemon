import React from 'react';
import {View} from 'react-native';

import {AppContainer} from 'src/components';

const App = () => {
  return (
    <AppContainer>
      <View>asd</View>
    </AppContainer>
  );
};

export default App;
